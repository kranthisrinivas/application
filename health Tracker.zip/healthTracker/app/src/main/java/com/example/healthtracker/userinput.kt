package com.example.healthtracker

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_userinput.*
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.*

class userinput : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private  val TAG = "userinputTAG"
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userinput)



        button6.setOnClickListener {
           var data = hashMapOf(

               "username" to PersonName2.text.toString(),
               "dob" to editTextNumber5.text.toString(),
               "weight" to editTextNumber.text.toString(),
               "height" to editTextNumber2.text.toString(),
               "weightToLose" to editTextNumber3.text.toString(),
               "targetMonths" to editTextNumber4.text.toString(),
               "calories" to "0",
               "lastUpdate" to DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS").withZone(ZoneOffset.UTC).format(Instant.now()).toString()


           )

            val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference
            auth = FirebaseAuth.getInstance();
            val user = auth.currentUser
            if (user != null) {
                ref.child("users").child(user.uid).child("personalData").updateChildren(data as Map<String, Any>).addOnSuccessListener {
                    Log.d(TAG, "Updating Personal data of User ")
                        val intent= Intent(this,MainActivity ::class.java)
                        startActivity(intent)
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
                        finish()
                }
            }



        }
    }



}