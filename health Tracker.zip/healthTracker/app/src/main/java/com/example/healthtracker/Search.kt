package com.example.healthtracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.pacific.adapter.RecyclerAdapter
import kotlinx.android.synthetic.main.activity_search.*

class Search : AppCompatActivity() {


    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth: FirebaseAuth
    private  val TAG = "SearchTAG"
    var searchadapter = RecyclerAdapter()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        auth = FirebaseAuth.getInstance();
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
        val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference
        val user = auth.currentUser
            Log.d(TAG,"Started")

        searchRecycler.adapter =searchadapter



        ref.child("foodItems").get().addOnFailureListener {
            Log.d(TAG,"${it.toString()}")
        }            .addOnSuccessListener {

                Log.d(TAG,"Sucess")
                    it.children.forEach {
                        //Log.d(TAG,it.child("calories").value.toString())

                            var calories =it.child("calories").value
                        var carbs =it.child("carbs").value
                        var fat =it.child("fat").value
                        var protiens =it.child("protiens").value
                        var url =it.child("url").value
                        val item =foodItem(baseContext, calories.toString(),carbs.toString(), fat.toString(), protiens.toString(), url.toString(),it.key.toString())
                        searchadapter.add(item)
                        }

        }

        searchRecycler.adapter =searchadapter

       // var foodItem: List<String> = arrayListOf("Bonda", "Dosa", "chapathi","idli","dal","poori","rice")





    }
}