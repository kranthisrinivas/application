package com.example.healthtracker

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import coil.imageLoader
import coil.request.ImageRequest
import com.andrefrsousa.superbottomsheet.SuperBottomSheetFragment
import com.pacific.adapter.AdapterViewHolder
import com.pacific.adapter.SimpleRecyclerItem
import kotlinx.android.synthetic.main.fooditem.view.*
import kotlinx.android.synthetic.main.fooditem.view.imageView4

class classes {

}


//
//class MySheetFragment() : SuperBottomSheetFragment() {
//    var TAG = "MySheetFragment"
//
//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
//        super.onCreateView(inflater, container, savedInstanceState)
//
//        //val view = LayoutInflater.from(context).inflate(R.layout.weight, null)
//       //var view = inflater.inflate(R.layout.weight,null)
//
//        var view =inflater.inflate(R.layout.weight, container, false)
//        Log.d(TAG,"hgurhgiaegiyEGFIYf;iG;IFY;iygliyfgliyeagf;iUG;IAUGLIYG;UH;OI")
//        view.buttohkbjn103.visibility= View.GONE
//
////        view.textView102.setText("jgsvachksbjlnk")
////        var weight=0
////        view.buttohkbjn103.setOnClickListener {
////            weight++
////            textView102.setText("$weight")
////        }
////       view.button101.setOnClickListener {
////            if(weight==0)
////            {}
////            else{
////                weight--
////                textView102.setText("$weight")}
////        }
//        return inflater.inflate(R.layout.weight, container, false)
//    }
//}
//


class foodItem(context: Context,
               var calories :String,
               var carbs : String,
               var fat :String,
               var protiens :String,
               var url :String,
               var name: String,

               ) : SimpleRecyclerItem() {
    override fun onViewAttachedToWindow(holder: AdapterViewHolder) {
        super.onViewAttachedToWindow(holder)
        val v =holder.itemView

        val imageLoader = v.imageView4.context.imageLoader
        var request =ImageRequest.Builder(v.imageView4.context)
            .data(url)
            .target(v.imageView4)
            .build()
        imageLoader.enqueue(request)

        v.textView21.setText(name)
        v.textView22.setText(calories)
        v.setOnClickListener {


            val c: Context = v.getContext()
            val intent= Intent(c, item_details::class.java)
            intent.putExtra("calories",calories)
            intent.putExtra("carbs",carbs)
            intent.putExtra("fat",fat)
            intent.putExtra("protiens",protiens)
            intent.putExtra("url",url)
            intent.putExtra("name",name)
            c.startActivity(intent)


            //overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)


        }

    }
    override fun bind(holder: AdapterViewHolder) {
        //Working
    }

    override fun getLayout(): Int {
        return R.layout.fooditem
    }
}

