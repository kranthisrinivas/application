package com.example.healthtracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import coil.imageLoader
import coil.request.ImageRequest
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_sport_details.*
import kotlinx.android.synthetic.main.activity_weight_update.*
import kotlinx.android.synthetic.main.fooditem.view.*

class sport_details : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sport_details)
        var time=textView25.text.toString().toInt()
        button9.setOnClickListener {
            time++
            textView25.setText("$time")
        }
        button12.setOnClickListener {
            if(time==0)
            {}
            else{
                time--
                textView25.setText("$time")}
        }
        val imageLoader = imageView5.context.imageLoader
        var request = ImageRequest.Builder(imageView5.context)
            .data("https://firebasestorage.googleapis.com/v0/b/health-tracker-23d01.appspot.com/o/sports%2Fcricket.jpg?alt=media&token=2447418a-dd4d-48ac-a2c5-d5fe89e888c8")
            .target(imageView5)
            .build()
        imageLoader.enqueue(request)
        auth = FirebaseAuth.getInstance();
        var  value =textView25.text.toString().toDouble()*100
        button13.setOnClickListener {
            var user = auth.currentUser
            val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference

            var data = hashMapOf(
                "weight" to value.toString()
            )
            if (user != null) {
                ref.child("users").child(user.uid).child("personalData").updateChildren(data as Map<String, Any>).addOnSuccessListener {
                    onBackPressed()
                }
            }
        }

    }
}