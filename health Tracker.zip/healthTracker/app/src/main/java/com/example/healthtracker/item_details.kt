package com.example.healthtracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import coil.imageLoader
import coil.request.ImageRequest
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_item_details.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.textView14
import kotlinx.android.synthetic.main.fooditem.view.*

class item_details : AppCompatActivity() {
    var tc =0.0
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth: FirebaseAuth
        val TAG = "item_detailsTAG"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_details)
        var calories=intent.getCharSequenceExtra("calories")
        var carbs=intent.getCharSequenceExtra("carbs")
        var protiens=intent.getCharSequenceExtra("protiens")
        var fat=intent.getCharSequenceExtra("fat")
        var name=intent.getCharSequenceExtra("name")
        var url=intent.getCharSequenceExtra("url")

        textView3.setText(calories)
        textView9.setText(carbs)
        textView15.setText(protiens)
        textView16.setText(fat)
        textView3.setText(calories)
        textView29.setText(fat)
        textView33.setText(carbs)
        textView35.setText(calories)
        textView99.setText(name)
        val imageLoader = imageView5.context.imageLoader
        var request = ImageRequest.Builder(imageView5.context)
            .data(url)
            .target(imageView5)
            .build()
        imageLoader.enqueue(request)



        var qua=0
        button12.setOnClickListener {
            qua++
            textView25.setText("$qua")
        }
        button9.setOnClickListener {
            if(qua==0)
            {}
            else{
                qua--
                textView25.setText("$qua")}
        }


        button13.setOnClickListener {

            tc=calories.toString().toDouble()*qua
            updateDB()


            val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference


        }





        }

    private fun updateDB() {

        Log.d(TAG,"Button Pressed")
        var user =FirebaseAuth.getInstance().currentUser
        val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference



        if (user!=null){

            ref.child("users").child(user.uid).child("personalData").get().addOnSuccessListener {
               var d= it.child("calories").value.toString().toDouble()
                var ss =(d+tc)
                var data = hashMapOf(
                    "calories" to ss.toString()
                )
                ref.child("users").child(user.uid).child("personalData").updateChildren(data as Map<String, Any>)

            }

        }
    }


}
