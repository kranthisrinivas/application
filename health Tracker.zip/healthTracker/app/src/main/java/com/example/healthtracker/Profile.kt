package com.example.healthtracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import coil.imageLoader
import coil.request.ImageRequest
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_profile.*
//import kotlinx.android.synthetic.main.category_item.view.*

class Profile : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth :FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_GAMES_SIGN_IN)
            .requestIdToken(getString(R.string.firebase_client_id)).requestId().build()
        googleSignInClient = GoogleSignIn.getClient(this,gso)

        auth = FirebaseAuth.getInstance()



        val user = auth.currentUser


        button.setOnClickListener {

            auth.signOut()
            googleSignInClient.signOut().addOnSuccessListener {
                val intent= Intent(this,login::class.java)
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
                finish()
            }

        }

        var ref = FirebaseDatabase.getInstance().reference
        if (user != null) {
            ref.child("users").child(user.uid).get().addOnSuccessListener {
                val imageLoader = imageView2.context.imageLoader

                val request = ImageRequest.Builder(imageView2.context)
                    .data("https://robohash.org/${it.child("userName").value.toString()}")
                    .target(imageView2)
                    .build()
                imageLoader.enqueue(request)
                textView9.setText(it.child("personalData").child("username").value.toString())
                textView11.setText(it.child("userEmail").value.toString())
                textView13.setText(it.child("userName").value.toString())
                textView13.setText(it.child("userName").value.toString())
                textView15.setText(it.child("lastLogin").value.toString())
                textView37.setText(it.child("personalData").child("calories").value.toString())
            }
        }






    }
}