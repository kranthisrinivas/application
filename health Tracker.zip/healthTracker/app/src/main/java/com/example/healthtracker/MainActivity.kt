package com.example.healthtracker

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.fitness.Fitness
import com.google.android.gms.fitness.data.DataType
import com.google.android.gms.fitness.data.Field
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_main.*
import com.google.android.gms.fitness.FitnessOptions
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener


class MainActivity : AppCompatActivity() {
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth: FirebaseAuth
    private  val TAG = "MainActivityTAG"
    var running = false
    var everyDayTarget =0.0
    var sensorManager: SensorManager? = null
    private val fitnessOptions: FitnessOptions by lazy {
        FitnessOptions.builder()
            .addDataType(DataType.TYPE_STEP_COUNT_CUMULATIVE)
            .addDataType(DataType.TYPE_STEP_COUNT_DELTA)
            .build()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance();
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),200)
            // Permission is not granted

        }
        fitSignIn()
        val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference
        val user = auth.currentUser
        button10.setOnClickListener {
            val intent= Intent(this,sports ::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
        }

        button3.setOnClickListener {
            val intent= Intent(this,WeightUpdate ::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
        }

        button.setOnClickListener {
            val intent= Intent(this, Search::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
            //finish()
        }
        imageView18.setOnClickListener {
            val intent= Intent(this, Profile::class.java)
            startActivity(intent)
            overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out)
            //finish()
        }

        val postListener = object : ValueEventListener {
            override fun onDataChange(it: DataSnapshot) {

                // Get Post object and use the values to update the UI
                textView4.setText(it.child("username").value.toString())
                textView12.setText(it.child("weight").value.toString())
                var weighttoLoseCalories =  it.child("weightToLose").value.toString().toInt()*7700
                var targetmonths =it.child("targetMonths").value.toString().toInt()*30
                everyDayTarget =Math.ceil((weighttoLoseCalories/targetmonths).toDouble())
                circularProgressBar.progressMax = everyDayTarget.toFloat()
                var calories =it.child("calories").value.toString()


                textView6.setText("${everyDayTarget} calories")
                //val post = dataSnapshot.getValue<Post>()
                // ...
            }
            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException())
            }
        }
        if (user != null) {
            ref.child("users").child(user.uid).child("personalData").addValueEventListener(postListener)
        }
        var water=0
        button4.setOnClickListener {
            water++
            textView14.setText("$water")
        }
        button5.setOnClickListener {
            if(water==0)
            {}
            else{
            water--
            textView14.setText("$water")}
        }
    }
    private fun fitSignIn() {
        if (oAuthPermissionsApproved()) {
            readDailySteps()
        } else {
            GoogleSignIn.requestPermissions(
                this,
                SIGN_IN_REQUEST_CODE,
                getGoogleAccount(),
                fitnessOptions
            )
        }
    }

    private fun oAuthPermissionsApproved() =
        GoogleSignIn.hasPermissions(getGoogleAccount(), fitnessOptions)
    private fun getGoogleAccount(): GoogleSignInAccount =
        GoogleSignIn.getAccountForExtension(this, fitnessOptions)
    override fun onActivityResult(
        requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            RESULT_OK -> {
                readDailySteps()
            }
            else -> {
                // Handle error.
            }
        }
    }
    @SuppressLint("SetTextI18n")
    private fun readDailySteps() {

        Fitness.getHistoryClient(this,getGoogleAccount())
            .readDailyTotal(DataType.AGGREGATE_CALORIES_EXPENDED)
            .addOnSuccessListener {
                val calories = when {
                    it.isEmpty -> 0
                    else -> it.dataPoints.first()
                        .getValue(Field.FIELD_CALORIES).asFloat()
                }

                textView6.setText("${calories} Calories Burned Today")
                circularProgressBar.progress = calories as Float
            }
        Fitness.getHistoryClient(this,getGoogleAccount())
            .readDailyTotal(DataType.AGGREGATE_DISTANCE_DELTA)
            .addOnSuccessListener {
                val distance = when {
                    it.isEmpty -> 0
                    else -> it.dataPoints.first()
                        .getValue(Field.FIELD_DISTANCE).toString()
                }
                textView6.setText("${distance} Calories Burned Today")
            }

        Fitness.getHistoryClient(this, getGoogleAccount())
            .readDailyTotal(DataType.TYPE_STEP_COUNT_DELTA)
            .addOnSuccessListener { dataSet ->
                val steps    = when {
                    dataSet.isEmpty -> 0
                    else -> dataSet.dataPoints.first()
                        .getValue(Field.FIELD_STEPS).asInt()
                }
                progressBar2.max =2000
                progressBar2.progress =steps
                //textView6.setText("$calories".toString())
                Log.i(TAG, "Total steps: $steps")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "There was a problem getting the step count.", e)
            }
    }

    companion object {
        const val SIGN_IN_REQUEST_CODE = 1001

    }
}