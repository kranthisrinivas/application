package com.example.healthtracker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_weight_update.*

class WeightUpdate : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_update)

        auth = FirebaseAuth.getInstance();
        var wt=textView102.text.toString().toInt()
        button100.setOnClickListener {
            wt++
            textView102.setText("$wt")
        }
        button101.setOnClickListener {
            if(wt==0)
            {}
            else{
                wt--
                textView102.setText("$wt")}
        }
        buttohkbjn103.setOnClickListener {
            var user = auth.currentUser
            val ref = FirebaseDatabase.getInstance("https://health-tracker-23d01-default-rtdb.asia-southeast1.firebasedatabase.app").reference

            var data = hashMapOf(
                "weight" to textView102.text.toString()
            )

            if (user != null) {
                ref.child("users").child(user.uid).child("personalData").updateChildren(data as Map<String, Any>).addOnSuccessListener {
                    onBackPressed()
                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}